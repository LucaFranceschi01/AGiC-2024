For this to work the TRAINING directory containing the training images should be in the same directory as this readme.

Disclaimer: this submission does not fulfill F-score > 20.0. In fact, the F score is 0 due to the fact that the recognition model always outputs -1 (for some reason I ignore). Kind of sad tbh.
